package br.com.payment.controller;

public class PaymentController {

}
